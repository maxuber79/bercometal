<!-- sidebar -->
<div id="" class="col-lg-4 sidebar-widgets">
	<div class="widget-wrap">
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Widget Page') ) :  endif; ?>
	</div>
</div>
<!-- ENDS sidebar -->