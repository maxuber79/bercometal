<div class="row">
    <div class="col-12 text-center">
        <div class="alert alert-info mt-5" role="alert">   
            <h2 class="alert-heading">404</h2>
            <p>Algo salió mal</p>
            <p>Oops! Lo sentimos este contenido ya no exite</p>
            <hr>
            <a href="<?php echo get_home_url(); ?>" class="btn btn-error">Volver al sitio!</a>
        </div><!-- mensaje de error -->
    </div>
</div>  